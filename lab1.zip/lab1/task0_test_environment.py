from viewer import SimpleViewer

if __name__ == "__main__":
    viewer = SimpleViewer()
    viewer.run()
